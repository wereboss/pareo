import sqlite3
from datetime import datetime
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
DB_FILE = BASE_DIR / "pareo.db"

def get_conn():
    """Returns a dictionary-like cursor connection configured with performance PRAGMAs."""
    # check_same_thread=False allows FastAPI/Asyncio to share the connection safely
    conn = sqlite3.connect(str(DB_FILE), check_same_thread=False)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode = WAL;")
    conn.execute("PRAGMA synchronous = NORMAL;")
    conn.execute("PRAGMA busy_timeout = 5000;")
    conn.execute("PRAGMA wal_autocheckpoint = 1000;")
    return conn

def init_db():
    """Creates the schema and performance indices if they don't exist."""
    with get_conn() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS tasks (
                task_id TEXT PRIMARY KEY,
                command TEXT,
                status TEXT,
                output TEXT,
                start_time TEXT,
                end_time TEXT,
                queue_name TEXT
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS library_cache (
                library_name TEXT,
                subpath TEXT,
                deep_scan INTEGER,
                cache_data TEXT,
                cached_at TEXT,
                PRIMARY KEY (library_name, subpath, deep_scan)
            )
        """)
        conn.commit()
        
        # Ensure queue_name column exists for older databases (migration fallback)
        try:
            conn.execute("ALTER TABLE tasks ADD COLUMN queue_name TEXT")
            conn.commit()
        except sqlite3.OperationalError:
            pass

        # Ensure pid column exists for detached process monitoring
        try:
            conn.execute("ALTER TABLE tasks ADD COLUMN pid INTEGER")
            conn.commit()
        except sqlite3.OperationalError:
            pass

        # Migrate NULL queue_names to their correct legacy mappings
        conn.execute("""
            UPDATE tasks
            SET queue_name = CASE
                WHEN command LIKE 'ffmpeg%' THEN 'media'
                WHEN command LIKE 'aria2c%' THEN 'network'
                WHEN command LIKE 'cp %' OR command LIKE 'mv %' OR command LIKE 'rm %' OR command LIKE 'tar %' OR command LIKE 'scp %' THEN 'fs'
                ELSE 'default'
            END
            WHERE queue_name IS NULL
        """)
        conn.commit()

        # B-Tree indices for status filtering, queue scheduling, and timeline pagination
        conn.execute("CREATE INDEX IF NOT EXISTS idx_tasks_status ON tasks(status);")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_tasks_queue_status ON tasks(queue_name, status);")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_tasks_start_time ON tasks(start_time DESC);")
        conn.commit()

def vacuum_db():
    """Reclaims unallocated pages resulting from task output pruning."""
    with get_conn() as conn:
        conn.execute("VACUUM;")
        conn.commit()

def insert_task(task_id: str, command: str, status: str, start_time: str, queue_name: str = "default"):
    with get_conn() as conn:
        conn.execute(
            "INSERT INTO tasks (task_id, command, status, output, start_time, end_time, queue_name, pid) VALUES (?, ?, ?, ?, ?, ?, ?, NULL)",
            (task_id, command, status, "", start_time, "", queue_name)
        )
        conn.commit()

def update_task_status(task_id: str, status: str, end_time: str = ""):
    with get_conn() as conn:
        if end_time:
            conn.execute("UPDATE tasks SET status = ?, end_time = ? WHERE task_id = ?", (status, end_time, task_id))
        else:
            conn.execute("UPDATE tasks SET status = ? WHERE task_id = ?", (status, task_id))
        conn.commit()

def update_task_pid(task_id: str, pid: int):
    with get_conn() as conn:
        conn.execute("UPDATE tasks SET pid = ? WHERE task_id = ?", (pid, task_id))
        conn.commit()

def append_task_output(task_id: str, chunk: str):
    """Efficiently appends string chunks directly inside the database."""
    with get_conn() as conn:
        conn.execute("UPDATE tasks SET output = output || ? WHERE task_id = ?", (chunk, task_id))
        conn.commit()

def get_all_tasks():
    with get_conn() as conn:
        cur = conn.execute("SELECT * FROM tasks ORDER BY start_time DESC")
        return {row["task_id"]: dict(row) for row in cur.fetchall()}

def get_tasks_paginated(limit: int = 15, offset: int = 0, queue: str = None, status: str = None, command: str = None):
    """Retrieves metadata of historical tasks excluding logs with pagination and optional filtering."""
    query = "SELECT task_id, command, status, start_time, end_time, queue_name FROM tasks"
    conditions = []
    params = []
    
    if queue:
        conditions.append("queue_name = ?")
        params.append(queue)
    if status:
        if status.lower() == 'failed':
            conditions.append("status LIKE 'Failed%'")
        elif status.lower() == 'incomplete':
            conditions.append("status IN ('Pending', 'Running')")
        else:
            conditions.append("status = ?")
            params.append(status)
    if command:
        conditions.append("command LIKE ?")
        params.append(f"%{command}%")
        
    if conditions:
        query += " WHERE " + " AND ".join(conditions)
        
    query += " ORDER BY start_time DESC LIMIT ? OFFSET ?"
    params.extend([limit, offset])
    
    with get_conn() as conn:
        cur = conn.execute(query, params)
        return {row["task_id"]: dict(row) for row in cur.fetchall()}

def get_task(task_id: str):
    with get_conn() as conn:
        cur = conn.execute("SELECT * FROM tasks WHERE task_id = ?", (task_id,))
        row = cur.fetchone()
        return dict(row) if row else None

def get_task_counts():
    """Returns exact counts of ongoing (Running) and pending tasks."""
    with get_conn() as conn:
        cur = conn.execute("""
            SELECT 
                SUM(CASE WHEN status = 'Running' THEN 1 ELSE 0 END) as ongoing,
                SUM(CASE WHEN status = 'Pending' THEN 1 ELSE 0 END) as pending
            FROM tasks
        """)
        row = cur.fetchone()
        return {
            "ongoing": row["ongoing"] if row["ongoing"] is not None else 0,
            "pending": row["pending"] if row["pending"] is not None else 0
        }

# --- RECOVERY LOGIC ---

def mark_running_as_failed():
    """Marks tasks that were interrupted by a server shutdown as Failed."""
    with get_conn() as conn:
        end_time = datetime.now().isoformat()
        conn.execute(
            "UPDATE tasks SET status = 'Failed (Interrupted)', end_time = ? WHERE status = 'Running'",
            (end_time,)
        )
        conn.commit()

def get_pending_tasks():
    """Retrieves all tasks that were queued but never started."""
    with get_conn() as conn:
        cur = conn.execute("SELECT task_id, command, queue_name FROM tasks WHERE status = 'Pending' ORDER BY start_time ASC")
        return [
            {
                "task_id": row["task_id"], 
                "command": row["command"], 
                "queue_name": row["queue_name"]
            } for row in cur.fetchall()
        ]
    
def reset_task_for_retry(task_id: str, new_start_time: str):
    """Scrubs error output and resets a task to Pending."""
    with get_conn() as conn:
        conn.execute(
            "UPDATE tasks SET status = 'Pending', output = '', start_time = ?, end_time = '' WHERE task_id = ?",
            (new_start_time, task_id)
        )
        conn.commit()    

def update_task_start_time(task_id: str, start_time: str):
    """Updates the start time when a task officially moves out of the queue."""
    with get_conn() as conn:
        conn.execute("UPDATE tasks SET start_time = ? WHERE task_id = ?", (start_time, task_id))
        conn.commit()

def purge_tasks(age: str) -> int:
    """Purges historical tasks (excluding active Pending/Running ones) based on the age threshold."""
    from datetime import datetime, timedelta
    
    if age == 'all':
        query = "DELETE FROM tasks WHERE status NOT IN ('Pending', 'Running')"
        params = []
    else:
        now = datetime.now()
        if age == '1d':
            cutoff = now - timedelta(days=1)
        elif age == '1w':
            cutoff = now - timedelta(weeks=1)
        elif age == '2w':
            cutoff = now - timedelta(weeks=2)
        else:
            raise ValueError("Invalid age threshold")
            
        query = "DELETE FROM tasks WHERE status NOT IN ('Pending', 'Running') AND start_time < ?"
        params = [cutoff.isoformat()]
        
    with get_conn() as conn:
        res = conn.execute(query, params)
        conn.commit()
        return res.rowcount

def get_cached_library(library_name: str, subpath: str, deep_scan: bool) -> str:
    """Retrieves cached library data as JSON string if exists, otherwise None."""
    ds_val = 1 if deep_scan else 0
    with get_conn() as conn:
        cur = conn.execute(
            "SELECT cache_data FROM library_cache WHERE library_name = ? AND subpath = ? AND deep_scan = ?",
            (library_name, subpath, ds_val)
        )
        row = cur.fetchone()
        return row["cache_data"] if row else None

def set_cached_library(library_name: str, subpath: str, deep_scan: bool, cache_data: str):
    """Sets/updates cached library data as JSON string."""
    ds_val = 1 if deep_scan else 0
    cached_at = datetime.now().isoformat()
    with get_conn() as conn:
        conn.execute(
            """
            INSERT OR REPLACE INTO library_cache (library_name, subpath, deep_scan, cache_data, cached_at)
            VALUES (?, ?, ?, ?, ?)
            """,
            (library_name, subpath, ds_val, cache_data, cached_at)
        )
        conn.commit()