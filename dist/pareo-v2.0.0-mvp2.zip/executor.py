import asyncio
import uuid
import sys
import os
from datetime import datetime
from pathlib import Path
import subprocess
import database
from broadcaster import broadcaster

BASE_DIR = Path(__file__).resolve().parent

# Global references for workers and running processes
active_workers = []
running_processes = {}  # Tracks task_id -> asyncio subprocess object mapping

# Concurrency queues
task_queues = {
    "media": asyncio.Queue(),
    "network": asyncio.Queue(),
    "fs": asyncio.Queue(),       
    "default": asyncio.Queue()
}

async def start_task(command: str, queue_name: str = "default") -> str:
    """Inserts task into database, pushes to target queue, and broadcasts SSE events."""
    task_id = str(uuid.uuid4())
    start_time = datetime.now().isoformat()
    
    database.insert_task(task_id, command, "Pending", start_time, queue_name)
    
    target_queue = task_queues.get(queue_name, task_queues["default"])
    await target_queue.put((task_id, command))
    
    print(f"[*] Pushed task {task_id[:8]} into queue: {queue_name.upper()}")
    
    # Broadcast to SSE clients
    broadcaster.broadcast_task_update(task_id, "Pending", queue_name, start_time)
    counts = database.get_task_counts()
    broadcaster.broadcast_task_counts(counts["ongoing"], counts["pending"])
    
    return task_id

def resolve_queue_from_command(command: str) -> str:
    """Fallback router to detect queue type for legacy tasks lacking queue_name."""
    cmd_lower = command.lower()
    if cmd_lower.startswith("ffmpeg"):
        return "media"
    elif cmd_lower.startswith("aria2c"):
        return "network"
    elif any(cmd_lower.startswith(prefix) for prefix in ["cp ", "mv ", "rm ", "tar ", "scp "]):
        return "fs"
    return "default"

def recover_tasks():
    """Runs on server boot to handle orphaned tasks and requeue pending ones in their correct queues."""
    # 1. Fetch running tasks and verify if they are still alive
    with database.get_conn() as conn:
        cur = conn.execute("SELECT * FROM tasks WHERE status = 'Running'")
        running_tasks = [dict(row) for row in cur.fetchall()]
        
    for rt in running_tasks:
        task_id = rt["task_id"]
        pid = rt.get("pid")
        still_running = False
        if pid:
            try:
                # Signal 0 checks process existence without killing it
                os.kill(pid, 0)
                still_running = True
            except (ProcessLookupError, PermissionError):
                pass
        
        if still_running:
            print(f"[*] Task {task_id[:8]} (PID {pid}) is still running in the background. Letting it finish.")
        else:
            print(f"[*] Task {task_id[:8]} (PID {pid}) is no longer active. Marking as Failed (Interrupted).")
            end_time = datetime.now().isoformat()
            database.update_task_status(task_id, "Failed (Interrupted)", end_time)
            database.append_task_output(task_id, "\n[Task interrupted due to server reboot]")
            
    # 2. Recover pending tasks
    pending = database.get_pending_tasks()
    for pt in pending:
        q_name = pt.get("queue_name")
        if not q_name:
            q_name = resolve_queue_from_command(pt["command"])
            
        target_queue = task_queues.get(q_name, task_queues["default"])
        target_queue.put_nowait((pt["task_id"], pt["command"]))
        print(f"[*] Recovered pending task {pt['task_id'][:8]} into queue: {q_name.upper()}")
    
    return len(pending)

async def _read_stream(stream, task_id):
    """Reads stream in chunks and writes directly to SQLite."""
    while True:
        chunk = await stream.read(1024)
        if not chunk:
            break
        
        decoded_chunk = chunk.decode('utf-8', errors='replace').replace('\r', '\n')
        if decoded_chunk:
            database.append_task_output(task_id, decoded_chunk)
            broadcaster.broadcast_task_output(task_id, decoded_chunk)
            await asyncio.sleep(0.05)

async def fire_immediate_command(command: str, detached: bool = False) -> dict:
    """Executes a command immediately. If detached, spawns an independent OS process."""
    if detached:
        try:
            process = subprocess.Popen(
                command,
                shell=True,
                start_new_session=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL
            )
            output_msg = (
                f"Detached process successfully spawned.\n"
                f"PID: {process.pid}\n"
                f"Command: {command}"
            )
            return {"success": True, "output": output_msg}
        except Exception as e:
            return {"success": False, "output": f"Failed to spawn detached process: {str(e)}"}

    try:
        process = await asyncio.create_subprocess_shell(
            command,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE
        )
        
        try:
            stdout, stderr = await asyncio.wait_for(process.communicate(), timeout=30.0)
        except asyncio.TimeoutError:
            process.kill()
            return {"success": False, "output": "Execution timed out after 30 seconds."}

        return_code = process.returncode
        output = stdout.decode('utf-8').strip()
        error = stderr.decode('utf-8').strip()
        
        if return_code == 0:
            return {"success": True, "output": output if output else "Executed successfully."}
        else:
            return {"success": False, "output": error if error else f"Failed with code {return_code}."}
            
    except Exception as e:
        return {"success": False, "output": str(e)}

async def run_command(task_id: str, command: str):
    # Check if task was cancelled while pending in queue
    task = database.get_task(task_id)
    if not task or task["status"] == "Cancelled":
        print(f"[*] Skipping task {task_id[:8]} as it was Cancelled while pending.")
        return

    # Capture exact time the worker picked it up
    actual_start_time = datetime.now().isoformat()
    database.update_task_start_time(task_id, actual_start_time)
    database.update_task_status(task_id, "Running")
    
    q_name = task.get("queue_name", "default")
    broadcaster.broadcast_task_update(task_id, "Running", q_name, actual_start_time)
    counts = database.get_task_counts()
    broadcaster.broadcast_task_counts(counts["ongoing"], counts["pending"])
    
    try:
        # Spawn the detached task_runner.py process
        runner_path = str(BASE_DIR / "task_runner.py")
        cmd_args = [
            sys.executable, runner_path,
            "--task-id", task_id,
            "--command", command
        ]
        
        process = await asyncio.create_subprocess_exec(
            *cmd_args,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
            start_new_session=True
        )
        
        running_processes[task_id] = process
        
        # Read the stdout stream of task_runner to push chunks via SSE bus
        async def _stream_runner_chunks(stream):
            while True:
                chunk = await stream.read(1024)
                if not chunk:
                    break
                decoded = chunk.decode('utf-8', errors='replace')
                if decoded:
                    broadcaster.broadcast_task_output(task_id, decoded)

        # Read stderr of task_runner for runner diagnostics
        async def _log_runner_stderr(stream):
            while True:
                line = await stream.readline()
                if not line:
                    break
                decoded = line.decode('utf-8', errors='replace').strip()
                if decoded:
                    print(f"[Runner {task_id[:8]}] {decoded}")

        await asyncio.gather(
            _stream_runner_chunks(process.stdout),
            _log_runner_stderr(process.stderr)
        )
        
        await process.wait()
            
    except Exception as e:
        end_time = datetime.now().isoformat()
        database.append_task_output(task_id, f"\nFailed to spawn task runner: {str(e)}")
        database.update_task_status(task_id, "Failed (Launcher Exception)", end_time)
    finally:
        running_processes.pop(task_id, None)
        task_after = database.get_task(task_id)
        final_status = task_after["status"] if task_after else "Completed"
        broadcaster.broadcast_task_update(task_id, final_status, q_name, actual_start_time)
        counts = database.get_task_counts()
        broadcaster.broadcast_task_counts(counts["ongoing"], counts["pending"])

async def cancel_task(task_id: str) -> bool:
    """Cancels a task. If running, terminates the detached subprocess group. If pending, updates status to Cancelled."""
    task = database.get_task(task_id)
    if not task:
        raise ValueError("Task not found.")
        
    q_name = task.get("queue_name", "default")
    start_time = task.get("start_time", "")
    
    if task["status"] == "Running":
        pid = task.get("pid")
        if pid:
            try:
                import signal
                # Terminate the entire process group of the task_runner
                os.killpg(pid, signal.SIGTERM)
            except ProcessLookupError:
                pass
            except Exception as e:
                print(f"[!] Error terminating process group {pid} for task {task_id}: {str(e)}")
        
        end_time = datetime.now().isoformat()
        database.update_task_status(task_id, "Cancelled", end_time)
        database.append_task_output(task_id, "\n[Task Cancelled by User]")
        
        broadcaster.broadcast_task_update(task_id, "Cancelled", q_name, start_time)
        counts = database.get_task_counts()
        broadcaster.broadcast_task_counts(counts["ongoing"], counts["pending"])
        return True
        
    elif task["status"] == "Pending":
        end_time = datetime.now().isoformat()
        database.update_task_status(task_id, "Cancelled", end_time)
        database.append_task_output(task_id, "\n[Task Cancelled by User while Pending]")
        
        broadcaster.broadcast_task_update(task_id, "Cancelled", q_name, start_time)
        counts = database.get_task_counts()
        broadcaster.broadcast_task_counts(counts["ongoing"], counts["pending"])
        return True
        
    raise ValueError("Only Pending or Running tasks can be cancelled.")

async def retry_task(task_id: str):
    """Validates and pushes a failed task back into the worker queue."""
    task = database.get_task(task_id)
    if not task:
        raise ValueError("Task not found.")
        
    # Allow retrying Failed, Cancelled, or Interrupted tasks
    if task['status'] in ['Completed', 'Pending', 'Running']:
        raise ValueError("Only failed, cancelled, or interrupted tasks can be retried.")
        
    new_start_time = datetime.now().isoformat()
    database.reset_task_for_retry(task_id, new_start_time)
    
    # Push retries to the correct queue
    q_name = task.get("queue_name")
    if not q_name:
        q_name = resolve_queue_from_command(task['command'])
    target_queue = task_queues.get(q_name, task_queues["default"])
    await target_queue.put((task_id, task['command']))
    
    broadcaster.broadcast_task_update(task_id, "Pending", q_name, new_start_time)
    counts = database.get_task_counts()
    broadcaster.broadcast_task_counts(counts["ongoing"], counts["pending"])
    return True

def get_queue_concurrency(queue_name: str) -> int:
    """Loads max allowed concurrent tasks per queue from config.json or default values."""
    try:
        import command_builder
        config = command_builder.load_config()
        concurrency_settings = config.get("queue_settings", {}).get("concurrency", {})
        if queue_name in concurrency_settings:
            return int(concurrency_settings[queue_name])
    except Exception:
        pass
    
    default_concurrency = {
        "media": 1,
        "network": 2,
        "fs": 2,
        "default": 1
    }
    return default_concurrency.get(queue_name, 1)

async def worker(queue_name: str, queue: asyncio.Queue, worker_id: int = 1):
    """A dedicated worker listening to its specific queue with concurrency control."""
    print(f"[*] Started background worker {worker_id} for queue: {queue_name.upper()}")
    while True:
        task_id, command = await queue.get()
        print(f"[{queue_name.upper()} WORKER {worker_id}] Picked up task {task_id[:8]}")
        
        try:
            max_concurrent = get_queue_concurrency(queue_name)
            # Check if active running tasks in this queue reached max_concurrent limit
            while True:
                running_tasks = []
                with database.get_conn() as conn:
                    cur = conn.execute(
                        "SELECT task_id, pid FROM tasks WHERE queue_name = ? AND status = 'Running' AND task_id != ?",
                        (queue_name, task_id)
                    )
                    running_tasks = [dict(row) for row in cur.fetchall()]
                
                still_active_count = 0
                for rt in running_tasks:
                    pid = rt.get("pid")
                    if pid:
                        try:
                            os.kill(pid, 0)
                            still_active_count += 1
                        except (ProcessLookupError, PermissionError):
                            pass
                
                if still_active_count < max_concurrent:
                    break
                
                # If active running tasks reached concurrency limit, wait 0.5s before checking again
                await asyncio.sleep(0.5)

            # Execute the command
            await run_command(task_id, command)
            
        except Exception as e:
            print(f"[{queue_name.upper()} WORKER {worker_id} FATAL ERROR] Task {task_id[:8]} caused a thread crash: {str(e)}")
            try:
                database.update_task_status(task_id, "Failed (Worker Exception)", datetime.now().isoformat())
                counts = database.get_task_counts()
                broadcaster.broadcast_task_update(task_id, "Failed (Worker Exception)", queue_name)
                broadcaster.broadcast_task_counts(counts["ongoing"], counts["pending"])
            except Exception:
                pass 
                
        finally:
            queue.task_done()

def start_workers():
    """Spawns independent worker tasks for each queue type according to concurrency config."""
    for q_name, q in task_queues.items():
        concurrency = get_queue_concurrency(q_name)
        for i in range(concurrency):
            task = asyncio.create_task(worker(q_name, q, worker_id=i+1))
            active_workers.append(task)

async def stop_workers():
    """Cancels all active worker tasks and waits for them to exit."""
    print("[*] Stopping background workers...")
    for task in active_workers:
        task.cancel()
    if active_workers:
        await asyncio.gather(*active_workers, return_exceptions=True)
        active_workers.clear()
    print("[*] All background workers stopped.")

def get_queue_metrics() -> dict:
    """Returns queue saturation, active worker counts, and pending depth per queue."""
    metrics = {}
    for q_name, q in task_queues.items():
        limit = get_queue_concurrency(q_name)
        active = 0
        try:
            with database.get_conn() as conn:
                cur = conn.execute(
                    "SELECT COUNT(*) as cnt FROM tasks WHERE queue_name = ? AND status = 'Running'",
                    (q_name,)
                )
                row = cur.fetchone()
                if row:
                    active = row["cnt"]
        except Exception:
            active = 0
        pending = q.qsize()
        sat_pct = round((active / limit) * 100, 1) if limit > 0 else 0.0
        metrics[q_name] = {
            "active": active,
            "pending": pending,
            "limit": limit,
            "saturation_pct": sat_pct
        }
    return metrics

async def batch_cancel_tasks(task_ids: list) -> list:
    """Cancels multiple tasks, terminating running process groups and updating statuses."""
    cancelled = []
    for tid in task_ids:
        try:
            if await cancel_task(tid):
                cancelled.append(tid)
        except Exception:
            pass
    return cancelled

async def batch_retry_tasks(task_ids: list) -> list:
    """Retries multiple failed or cancelled tasks."""
    retried = []
    for tid in task_ids:
        try:
            if await retry_task(tid):
                retried.append(tid)
        except Exception:
            pass
    return retried

async def batch_purge_tasks(task_ids: list) -> list:
    """Purges multiple finished or cancelled tasks from the database."""
    return database.batch_purge_tasks(task_ids)